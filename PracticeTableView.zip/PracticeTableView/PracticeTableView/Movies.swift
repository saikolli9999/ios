//
//  Movies.swift
//  PracticeTableView
//
//  Created by Kolli,Sai Kumar on 4/27/23.
//

import Foundation
import UIKit

struct Genre {
    var category : String
    var movies : [MoviesList] = []
    
}

struct MoviesList {
    var movieName : String
    var image : UIImage
}

let G1 = Genre(category: "Horror",movies: [MoviesList(movieName: "CHandramukhi", image: UIImage(named: "cmukhi")!),MoviesList(movieName: "Raksha", image: UIImage(named: "raksha")!)])

let G2 = Genre(category: "comedy",movies: [MoviesList(movieName: "Dookudu", image: UIImage(named: "dookudu")!),MoviesList(movieName: "Badsha", image: UIImage(named: "badsha")!)])

let MoviesArray = [G1,G2]
