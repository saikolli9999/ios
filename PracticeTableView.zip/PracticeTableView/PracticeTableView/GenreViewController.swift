//
//  ViewController.swift
//  PracticeTableView
//
//  Created by Kolli,Sai Kumar on 4/27/23.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return MoviesData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = genreTableView.dequeueReusableCell(withIdentifier: "genreCell", for: indexPath)
        cell.textLabel?.text = MoviesData[indexPath.row].category
        return cell
    }
    

    
    @IBOutlet weak var genreTableView: UITableView!
    var MoviesData = MoviesArray
    
    override func viewDidLoad() {
        super.viewDidLoad()
        genreTableView.delegate = self
        genreTableView.dataSource = self
        // Do any additional setup after loading the view.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var transition = segue.identifier
        if(transition=="movieSegue") {
            var destination = segue.destination as! MoviesViewController
            destination.Movies = MoviesData[(genreTableView.indexPathForSelectedRow?.row)!]
        }
    }


}

