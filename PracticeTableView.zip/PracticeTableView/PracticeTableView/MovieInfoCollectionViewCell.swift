//
//  MovieInfoViewCellCollectionViewCell.swift
//  PracticeTableView
//
//  Created by Kolli,Sai Kumar on 4/27/23.
//

import UIKit

class MovieInfoViewCellCollectionViewCell: UICollectionViewCell {
    
}
