//
//  MoviesInfoCollectionViewCell.swift
//  PracticeTableView
//
//  Created by Kolli,Sai Kumar on 4/27/23.
//

import UIKit

class MoviesInfoCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var movieImageOutlet: UIImageView!
    func assignMovie(with Movie : MoviesList) {
        movieImageOutlet.image = Movie.image
    }
}
